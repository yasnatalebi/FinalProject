package Heros.Trolls;
import Heros.Hero;

public class Troll2 extends Hero
{
    public Troll2()
    {
        super("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\Troll2.png");
        setPower(50);
        setHealth(50);
        setSpeed(50);
    }
}

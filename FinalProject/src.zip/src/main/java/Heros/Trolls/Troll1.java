package Heros.Trolls;
import Heros.Hero;

public class Troll1 extends Hero
{
    public Troll1()
    {
        super("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\Troll1.png");
        setPower(100);
        setHealth(100);
        setSpeed(100);
    }
}

package Heros.Trolls;
import Heros.Hero;

public class Troll3 extends Hero
{
    public Troll3()
    {
        super("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\Troll3.png");
        setPower(40);
        setHealth(40);
        setSpeed(40);
    }
}

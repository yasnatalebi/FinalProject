package Heros.Knights;

import Heros.Hero;

public class Knight1 extends Hero
{
    public Knight1()
    {
        super("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\knight1.png");
        setPower(100);
        setHealth(100);
        setSpeed(100);
    }
}

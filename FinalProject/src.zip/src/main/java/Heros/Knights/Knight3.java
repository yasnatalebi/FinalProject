package Heros.Knights;

import Heros.Hero;

public class Knight3 extends Hero
{
    public Knight3()
    {
        super("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\knight3.png");
        setPower(40);
        setHealth(40);
        setSpeed(40);
    }
}

package Heros.Knights;

import Heros.Hero;

public class Knight2 extends Hero
{
    public Knight2()
    {
        super("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\knight2.png");
        setPower(50);
        setHealth(50);
        setSpeed(50);
    }
}

package MainPanel;

import Heros.Trolls.Troll1;
import Heros.Trolls.Troll2;
import Heros.Trolls.Troll3;
import javafx.scene.image.ImageView;

import java.util.ArrayList;

abstract public class CreateTrolls
{
    private static ArrayList<ImageView> viewTroll1;
    private static ArrayList<ImageView> viewTroll2;
    private static ArrayList<ImageView> viewTroll3;

    private static int troll1Counter = 0;
    private static int troll2Counter = 0;
    private static int troll3Counter = 0;

    public static void CreateTroll1()
    {
        Troll1 troll1 = new Troll1();
        viewTroll1.add(new ImageView(troll1));

        int randPosition = MoveTrolls.TrollsRandNumber();

        if (randPosition == 1)
        {
            viewTroll1.get(troll1Counter).setLayoutX(500);
            viewTroll1.get(troll1Counter).setLayoutY(175);
        }
        else if (randPosition == 2)
        {
            viewTroll1.get(troll1Counter).setLayoutX(500);
            viewTroll1.get(troll1Counter).setLayoutY(300);
        }
        else if (randPosition == 3)
        {
            viewTroll1.get(troll1Counter).setLayoutX(500);
            viewTroll1.get(troll1Counter).setLayoutY(450);
        }
        viewTroll1.get(troll1Counter).setFitWidth(250);
        viewTroll1.get(troll1Counter).setFitHeight(200);
        Game.gamePane.getChildren().add(viewTroll1.get(troll1Counter));
        troll1Counter++;
    }
    public static void CreateTroll2()
    {
        Troll2 troll2 = new Troll2();
        viewTroll2.add(new ImageView(troll2));

        int randPosition = MoveTrolls.TrollsRandNumber();

        if (randPosition == 1)
        {
            viewTroll2.get(troll2Counter).setLayoutX(500);
            viewTroll2.get(troll2Counter).setLayoutY(175);
        }
        else if (randPosition == 2)
        {
            viewTroll2.get(troll2Counter).setLayoutX(500);
            viewTroll2.get(troll2Counter).setLayoutY(300);
        }
        else if (randPosition == 3)
        {
            viewTroll2.get(troll2Counter).setLayoutX(500);
            viewTroll2.get(troll2Counter).setLayoutY(450);
        }
        viewTroll2.get(troll2Counter).setFitWidth(250);
        viewTroll2.get(troll2Counter).setFitHeight(200);
        Game.gamePane.getChildren().add(viewTroll2.get(troll2Counter));
        troll2Counter++;
    }
    public static void CreateTroll3()
    {
        Troll3 troll3 = new Troll3();
        viewTroll3.add(new ImageView(troll3));

        int randPosition = MoveTrolls.TrollsRandNumber();

        if (randPosition == 1)
        {
            viewTroll3.get(troll3Counter).setLayoutX(500);
            viewTroll3.get(troll3Counter).setLayoutY(175);
        }
        else if (randPosition == 2)
        {
            viewTroll3.get(troll3Counter).setLayoutX(500);
            viewTroll3.get(troll3Counter).setLayoutY(300);
        }
        else if (randPosition == 3)
        {
            viewTroll3.get(troll3Counter).setLayoutX(500);
            viewTroll3.get(troll3Counter).setLayoutY(450);
        }
        viewTroll3.get(troll3Counter).setFitWidth(250);
        viewTroll3.get(troll3Counter).setFitHeight(200);
        Game.gamePane.getChildren().add(viewTroll3.get(troll3Counter));
        troll3Counter++;
    }
}

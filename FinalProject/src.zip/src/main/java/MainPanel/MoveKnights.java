package MainPanel;

public class MoveKnights
{

}

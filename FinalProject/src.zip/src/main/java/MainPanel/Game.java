package MainPanel;


import Heros.Knights.Knight1;
import Heros.Knights.Knight2;
import Heros.Knights.Knight3;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Game
{
    public static AnchorPane gamePane;
    public Scene gameScene;
    public Stage gameStage;

    private static final int GAME_WIDTH = 800;
    private static final int GAME_HEIGHT = 650;

    private Stage menuStage;

    Game()
    {
        gamePane = new AnchorPane();
        gameScene = new Scene(gamePane, GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        gameStage = new Stage();
        gameStage.setScene(gameScene);
        // title & icon
        gameStage.getIcons().add(new Image("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\logo.png"));
        gameStage.setTitle("Knights vs Trolls");
    }

    public void CreateNewGame(Stage menuStage)
    {
        this.menuStage = menuStage;
        this.menuStage.hide();
        createBackground();
        CreateKnights.CreateKnight1();
        CreateKnights.CreateKnight2();
        CreateKnights.CreateKnight3();
        int randTroll = MoveTrolls.TrollsRandNumber();
        if (randTroll == 1)
            CreateTrolls.CreateTroll1();
        else if (randTroll == 2)
            CreateTrolls.CreateTroll2();
        else if (randTroll == 3)
            CreateTrolls.CreateTroll3();
        gameStage.show();
    }
    public void createBackground()
    {
        Image backgroundImage = new Image("C:\\Users\\Yasna\\IdeaProjects\\FinalProject\\src\\back.png", 800, 500, false, false);
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.SPACE, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,null);
        gamePane.setBackground(new Background(background));
    }

}

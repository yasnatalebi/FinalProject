package MainPanel;

public class MoveTrolls
{
    public static int TrollsRandNumber()
    {
        int min = 1;
        int max = 4;
        //Generate random int value from 1 to 3
        int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
        return random_int;
    }
}
